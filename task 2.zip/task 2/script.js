window.onload = function() {
    
    var inputBox = document.getElementById('task-input');
    var addButton = document.getElementById('add-btn');
    var listArea = document.getElementById('task-list');
  
    function addNewTask() {
      var text = inputBox.value;         
      text = text.trim();                
      if (text === '') {                 
        return;
      }
  
     
      var li = document.createElement('li');
      var span = document.createElement('span');
      span.innerText = text;             
  
      var buttonDiv = document.createElement('div');
      buttonDiv.className = 'task-buttons';
  
      var doneBtn = document.createElement('button');
      doneBtn.innerText = '✓';
      doneBtn.onclick = function() {     
        li.className = 'completed';      
      };
  
      var deleteBtn = document.createElement('button');
      deleteBtn.innerText = '✗';
      deleteBtn.onclick = function() {   
        listArea.removeChild(li);       
      };
  
      buttonDiv.appendChild(doneBtn);
      buttonDiv.appendChild(deleteBtn);
  
      li.appendChild(span);
      li.appendChild(buttonDiv);
  
      listArea.appendChild(li);
  
      inputBox.value = '';
      inputBox.focus();
    }
  
    addButton.onclick = addNewTask;
  
    inputBox.onkeypress = function(e) {
      if (e.key === 'Enter') {
        addNewTask();
      }
    };
  };