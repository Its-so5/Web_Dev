
const express = require('express');

const app = express();

const PORT = 3000;

app.use(express.json());


let books = [];

let nextId = 1;


app.get('/books', (req, res) => {
  res.json(books);
});

app.post('/books', (req, res) => {
  const { title, author } = req.body;

  if (!title || !author) {
    return res.status(400).json({ error: 'Missing title or author in request body.' });
  }

  const newBook = {
    id: nextId++,
    title,
    author,
  };
  books.push(newBook);
  res.status(201).json(newBook);
});

app.put('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id, 10);
  const { title, author } = req.body;

  const index = books.findIndex((b) => b.id === bookId);
  if (index === -1) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  if (title) books[index].title = title;
  if (author) books[index].author = author;

  res.json(books[index]);
});

app.delete('/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id, 10);
  const index = books.findIndex((b) => b.id === bookId);
  if (index === -1) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  const removed = books.splice(index, 1);
  res.json({ message: 'Book deleted.', book: removed[0] });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
